<?php
//FORMUL�RIO EXPORTARREL
define("_TITULO","Exportar Relat&oacute;rio");
define("_SELECIONE",":: Selecione ::");
define("_TIPOARQUIVO","Tipo de Arquivo");
define("_ORIENTACAO","Orienta&ccedil;&atilde;o");
define("_MARGENS","Margens (mm)");
define("_FONTE","Fonte");
define("_PAPEL","Papel");
define("_TAMANHO","Tamanho");
define("_DIR","Dir.");
define("_TOP","Sup.");
define("_ESQ","Esq.");
define("_EXPORTAR","Exportar");
define("_CANCELAR","Cancelar");
define("_RETRATO","Retrato");
define("_PAISAGEM","Paisagem");


//CLASSE EXPORTARREL
define("_ESCOLHAARQ","Escolha um tipo de Arquivo");
define("_PREENCHAPARAM","Preencha todos os parametros de configura��o");
?>