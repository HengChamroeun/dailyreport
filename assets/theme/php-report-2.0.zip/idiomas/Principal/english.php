<?php
//FORM PRINCIPAL
define("_TITULO","Welcome to PHP Report!");
define("_MSG","Use the buttons above to browse.");
?>