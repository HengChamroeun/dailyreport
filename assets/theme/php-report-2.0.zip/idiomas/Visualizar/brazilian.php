<?php
//FORMUL�RIO VISUALIZARREL
define("_TITULO","Relat&oacute;rio");
define("_VISUALIZAR","Visualizar");
define("_EDITAR","Editar");
define("_MODOEDICAO","Voltar para<br>modo de edi&ccedil;&atilde;o");
define("_SALVAR","Salvar");
define("_EXCLUIR","Excluir");
define("_EXPORTAR","Exportar");
define("_AVISO","Para n�o perder este relat�rio clique em Salvar ou em Voltar para modo de edi��o.");
define("_EXCLUIRCONF","Deseja excluir este relat�rio?");
define("_MSGPREVISUALIZAR","Redimensione as colunas conforme desejado");

//CLASSE VISUALIZARREL
define("_ERRORELATORIO","Ocorreu um erro no momento da grava&ccedil;&atilde;o do esquema deste relat&oacute;rio, edite-o e tente novamente.");
define("_RELNAOENCONTRADO","Relat&oacute;rio n&atilde;o encontrado.");
define("_USUNAOENCONTRADO","Usu&aacute;rio n&atilde;o encontrado.");
define("_GRUPO","Grupo");
define("_DATACRIACAO","Data de cria&ccedil;&atilde;o");
define("_USUCRIACAO","Usu&aacute;rio da cria&ccedil;&atilde;o");
define("_DATAEDICAO","Data de modifica&ccedil;&atilde;o");
define("_USUEDICAO","Usu&aacute;rio da modifica&ccedil;&atilde;o");
define("_BASEDADOS","Base de dados");
define("_PAGINA","P�gina");
define("_DE","de");

//CLASSE GERARRELSALVAR
define("_PREENCHATODOS","Algum campo do formul�rio n�o foi preenchido!");

//CLASSE GERARREL
define("_RELACIONMSMTABELA","Existe(m) relacionamento(s) entre a mesma tabela!");
define("_RELACIONDUPLICADO","Existe(m) relacionamento(s) entre as tabelas duplicado(s)!");
define("_PREENCHARELACION","Preencha todos os relacionamentos existentes entre as tabelas!");
define("_ACESSOBD","Acesso n�o autorizado � esta base de dados!");
?>