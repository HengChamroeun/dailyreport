<?php
//FORM GRUPOREL
define("_TITULO","Authentication");
define("_USUARIO","User");
define("_SENHA","Password");
define("_ENTRAR","Enter");

//CLASS GRUPOREL
define("_ACESSONEGADO","Incorrect user or password!");
?>